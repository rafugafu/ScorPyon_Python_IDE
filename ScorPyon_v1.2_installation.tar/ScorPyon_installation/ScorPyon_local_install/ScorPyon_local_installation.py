import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import os
import getpass
def install():
	global root
	root.destroy()
	root = tk.Tk()
	root.title('Progress')
	progress = ttk.Progressbar(root, length = 900)
	progress.pack(fill = 'x')
	os.system('mkdir ~/.local/share/ScorPyon')
	progress['value'] = 100
	file = open('Data/ScorPyon.desktop', 'a+')
	user = getpass.getuser()
	desktp = f'[Desktop Entry]\nVersion=1.0\nType=Application\nName=ScorPyon\nComment=Simple Python IDE\nExec=python3 /home/{user}/.local/share/ScorPyon/main.py\nIcon=/home/{user}/.local/share/ScorPyon/Icon.svg\nPath=/home/{user}/.local/share/ScorPyon\nTerminal=false\nStartupNotify=false'
	file.write(desktp)
	file.close()
	progress['value'] = 200
	try:
		os.system('cp Data/Icon.svg ~/.local/share/ScorPyon/')
		progress['value'] = 300
	except:
		mb.showerror('Error', 'You have not copied the data files correctly or they are not in the same directory')
	else:
		try:
			os.system('cp Data/main.py ~/.local/share/ScorPyon/')
			progress['value'] = 400
		except:
			mb.showerror('Error', 'You have not copied the data files correctly or they are not in the same directory')
		else:
			try:
				os.system('cp Data/runner.py ~/.local/share/ScorPyon/')
				progress['value'] = 500
			except:
				mb.showerror('Error', 'You have not copied the data files correctly or they are not in the same directory')
			else:
				try:
					os.system('cp Data/ScorPyon.desktop ~/.local/share/applications/')
					progress['value'] = 600
				except:
					mb.showerror('Error', 'You have not copied the data files correctly or they are not in the same directory')
				else:
					os.system('rm Data/ScorPyon.desktop')
					progress['value'] = 700
					os.system(f'chmod +x /home/{user}/.local/share/applications/ScorPyon.desktop')
					progress['value'] = 800
					file = open(f'/home/{user}/.bashrc', 'a+')
					file.write(f'\nalias ScorPyon="python3 /home/{user}/.local/share/ScorPyon/main.py"')
					os.system('source ~/.bashrc')
					progress['value'] = 900
					mb.showinfo('Success!', 'ScorPyon has successfully been installed.')
					root.destroy()
root = tk.Tk()
root.title('ScorPyon local installation')
procedure = tk.Listbox(root)
list = ['~/.local/share/applications/ -> ScorPyon.desktop', '~/.local/share/ -> ScorPyon/', '~/.local/share/ScorPyon/ -> main.py', '~/.local/share/ScorPyon/ -> runner.py', '~/.local/share/ScorPyon/ -> Icon.svg']
for item in list:
	procedure.insert('end', item)
procedure.pack(fill = 'both')
start = ttk.Button(root, text = 'Start', command = lambda: install())
start.pack(fill = 'x')
root.mainloop()
