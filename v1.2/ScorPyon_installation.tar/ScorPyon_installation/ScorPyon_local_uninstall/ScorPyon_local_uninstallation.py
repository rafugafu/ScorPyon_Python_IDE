import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import os
import getpass
def uninstall():
	global root
	root.destroy()
	root = tk.Tk()
	root.title('Progress')
	progress = ttk.Progressbar(root, length = 400)
	progress.pack(fill = 'x')
	os.system('rm -r ~/.local/share/ScorPyon/')
	progress['value'] = 100
	os.system('rm ~/.local/share/applications/ScorPyon.desktop')
	progress['value'] = 200
	user = getpass.getuser()
	with open(f'/home/{user}/.bashrc', 'r+') as file:
		lines = file.readlines()
	with open(f'/home/{user}/bashrcback', 'w+') as file:
		file.writelines(lines)
	progress['value'] = 300
	mb.showinfo('Info', 'the ~/.bashrc file has been backed up and coppied as ~/bashrcback.')
	newlines = []
	for item in lines:
		if item != f'alias ScorPyon="python3 /home/{user}/.local/share/ScorPyon/main.py"':
			newlines.append(item)
	file = open(f'/home/{user}/.bashrc', 'w+')
	file.writelines(newlines)
	os.system('source ~/.bashrc')
	file.close()
	progress['value'] = 400
	mb.showinfo('Success!', 'ScorPyon has successfully been uninstalled')
	root.destroy()
root = tk.Tk()
root.title('ScorPyon local uninstallation')
procedure = tk.Listbox(root)
list = ['~/.local/share/applications/ -> ScorPyon.desktop', '~/.local/share/ -> ScorPyon/', '~/.local/share/ScorPyon/ -> main.py', '~/.local/share/ScorPyon/ -> runner.py', '~/.local/share/ScorPyon/ -> Icon.svg']
for item in list:
	procedure.insert('end', item)
procedure.pack(fill = 'both')
start = ttk.Button(root, text = 'Start', command = lambda: uninstall())
start.pack(fill = 'x')
root.mainloop()

